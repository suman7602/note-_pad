from ast import Return
from turtle import title
from django.shortcuts import render,redirect
from django.http import HttpResponse 
from multiprocessing import context
from .models import Text

def todo(request):
    if request.method == 'POST':
        tit = request.POST['title'] 
        input = request.POST['task']
        Text.objects.create(title = tit , task=input)
        return redirect('todo')
    obj = Text.objects.all()
    context = {'texts': obj}
    return render(request, 'todo_list.html', context)

def delete_task(request,pk):
    obj = Text.objects.get(id=pk)
    obj.delete()
    return redirect('todo')


def update_task(request,pk):
    obj =Text.objects.get(id=pk)
    pre_task= obj.task
    pre_title = obj.title
    if request.method=="POST":
        new_task = request.POST['task']
        new_title =request.POST['title']
        obj.task= new_task 
        obj.title=new_title
        obj.save()
        return redirect('todo')
    obj = Text.objects.all()
    context ={'texts':obj,'task':pre_task,'title':pre_title}
    return render(request,'todo_list.html',context)


    

